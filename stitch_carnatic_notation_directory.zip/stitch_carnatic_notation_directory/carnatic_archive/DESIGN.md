---
name: Carnatic Archive
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d4'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#efe6e2'
  surface-container-highest: '#e9e1dc'
  on-surface: '#1e1b18'
  on-surface-variant: '#584141'
  inverse-surface: '#34302c'
  inverse-on-surface: '#f8efea'
  outline: '#8c7071'
  outline-variant: '#e0bfbf'
  surface-tint: '#af2b3e'
  primary: '#570013'
  on-primary: '#ffffff'
  primary-container: '#800020'
  on-primary-container: '#ff828a'
  inverse-primary: '#ffb3b5'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#272919'
  on-tertiary: '#ffffff'
  tertiary-container: '#3d3f2d'
  on-tertiary-container: '#a9aa94'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b5'
  on-primary-fixed: '#40000b'
  on-primary-fixed-variant: '#8e0f28'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e4e4cc'
  tertiary-fixed-dim: '#c8c8b0'
  on-tertiary-fixed: '#1b1d0e'
  on-tertiary-fixed-variant: '#474836'
  background: '#fff8f5'
  on-background: '#1e1b18'
  surface-variant: '#e9e1dc'
typography:
  headline-display:
    fontFamily: notoSerif
    fontSize: 42px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: notoSerif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: notoSerif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  notation-lg:
    fontFamily: notoSerif
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.6'
    letterSpacing: 0.1em
  body-lg:
    fontFamily: manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  caption:
    fontFamily: manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The brand personality is that of a "Reverent Scholar"—authoritative and deeply rooted in tradition, yet progressive and clear in its delivery. It aims to evoke a sense of calm, intellectual curiosity, and cultural pride. This design system treats musical compositions not just as files, but as artifacts.

The design style is **Minimalism with Tonal Layering**. It avoids excessive ornamentation, allowing the richness of the palette and the precision of the typography to convey the "Indian" aesthetic. By utilizing generous whitespace (negative space), the UI mimics the layout of a premium physical archive or a classical concert program. The emotional response should be one of "Digital Sanctuary"—a quiet, focused space for deep listening and learning.

## Colors

The palette is a contemporary distillation of traditional temple aesthetics. 
- **Primary (Deep Maroon):** Used for key branding elements, primary actions, and signifying "The Guru" or the source of authority.
- **Secondary (Warm Gold):** Reserved for highlights, active states, and interactive accents. It should be used sparingly to maintain its precious feel.
- **Background (Soft Cream):** The "canvas" of the application. It reduces eye strain compared to pure white and provides a warm, paper-like quality.
- **Neutral (Rich Charcoal):** Used for primary text to ensure high legibility against the cream background without the harshness of pure black.

Success, warning, and error states should be desaturated to stay within the sophisticated tone of the system.

## Typography

This design system uses a dual-font strategy to balance heritage with modern utility. 

**notoSerif** is utilized for all "Artistic" content. This includes Raga names, Composer titles, and most importantly, the **Swaras (S, R, G, M, P, D, N)**. The serif's modulated stroke widths mirror the organic nature of Carnatic gamakas (oscillations).

**manrope** handles the "System" content. It is used for navigational elements, technical metadata (Tala, Shruti, Duration), and functional labels. Its clean, geometric construction ensures the app feels like a modern tool.

For musical notations, always use the `notation-lg` style with increased letter spacing to ensure each syllable is distinct and readable during performance or study.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** approach for desktop to maintain the "archival record" aesthetic, and a fluid layout for mobile. A 12-column system is used, but content should ideally be centered and "breathe" with wide margins (`margin-desktop`).

Spacing follows an 8px rhythmic scale. However, to achieve the "scholarly" look, use `stack-lg` (48px) between major sections (e.g., between the player and the lyrics/notations) to prevent the UI from feeling cluttered. Alignment should be primarily left-aligned for text-heavy content (lyrics) to mirror traditional manuscripts.

## Elevation & Depth

Hierarchy in this design system is primarily conveyed through **Tonal Layers** rather than heavy shadows. 

1.  **Base Layer:** The Soft Cream (`#F5F5DC`) background.
2.  **Surface Layer:** Slightly lighter or sheer white overlays (50% opacity) used for cards and content containers to create a subtle "lift."
3.  **Interactive Layer:** Low-contrast outlines using a 1px stroke of the primary color at 15% opacity.

Shadows, if used, should be **Ambient Shadows**: extremely diffused (20px - 40px blur), very low opacity (5%), and tinted with the Deep Maroon primary color to maintain warmth. This creates a soft "glow" rather than a hard drop-shadow.

## Shapes

The shape language is **Soft** and restrained. While modern apps often trend toward hyper-rounded "pill" shapes, this design system uses subtle 4px (`rounded`) to 8px (`rounded-lg`) corners. This reflects the architectural precision found in Indian heritage sites—structured and geometric, but never sharp.

- **Buttons:** 4px radius (Soft) to maintain a formal, scholarly feel.
- **Cards/Containers:** 8px radius (Soft-Lg) for a gentle containment of information.
- **Selection States:** Use a bottom-border or a subtle fill rather than a rounded pill to keep the interface looking like a sophisticated document.

## Components

**Buttons:**
- **Primary:** Deep Maroon fill with Soft Cream text. High contrast, rectangular with a 4px radius.
- **Secondary:** Transparent with a 1px Gold border. Used for tertiary actions like "Add to Playlist."

**Notation Cards:**
Specific to this system, these cards hold Swara notations. They should use a light Cream surface with a Gold left-border accent to signify the current line being played. Swaras should be grouped in "Avartanams" (measures) using vertical dividers at 10% opacity.

**Chips / Tags:**
Used for Raga, Tala, and Melakarta classification. These should be "Ghost Chips"—no fill, just a 1px Rich Charcoal border at 20% opacity, using `label-md` typography.

**Inputs:**
Text fields should be "Bottom Line" only (Material-style) to mimic the lines of a notebook, using the Primary color for the active underline state.

**The "Shruti Box" Player:**
A specialized component that remains persistent. It should use a sheer Glassmorphic effect over the cream background to feel like it's floating above the archival content without obscuring it. Use Gold for the play/pause icons.